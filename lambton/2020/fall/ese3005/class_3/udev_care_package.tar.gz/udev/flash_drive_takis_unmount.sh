device_name="takis_drive"

umount "/dev/$device_name"
rmdir "/media/$device_name"


