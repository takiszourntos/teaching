Signals and Systems notes by Fred Nicolls
http://www.dip.ee.uct.ac.za/~nicolls
This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License

Uses Makefile to generate documents.  Must have latex and dvips executables on path.  Figures (.fig) generated with xfig and exported to eps.
